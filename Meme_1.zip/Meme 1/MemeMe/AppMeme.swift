//
//  AppDelegate.swift
//  Meme 1.0
//
//  Created by Banan Mohammed on 03/08/1440 AH.
//  Copyright © 1440 Banan Mohammed. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    let topText: String
    let bottomText: String
    let originalImage: UIImage
    let memedImage: UIImage
}
